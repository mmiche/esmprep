#' Resulting list after function setES has been executed.
#'
#' \strong{Note}: The list \code{RELEVANTINFO_ES} is the result of the function \code{\link{setES}}.
#'
#' @docType data
# @keywords datasets
# @name RELEVANTINFO_ES
#
# @source R package esmprep.
"RELEVANTINFO_ES"